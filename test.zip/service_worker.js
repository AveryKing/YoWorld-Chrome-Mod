/** Sends message back to the YoVilleApp. Pass a JSON object
 *  to this function and it will be sent to the game via inject.js
 */
const sendRequest = async (yoPayload) => {
    return new Promise((resolve) => {
        chrome.tabs.query({active: true, currentWindow: true}, async (tabs) => {
            chrome.tabs.sendMessage(tabs[0].id, yoPayload, (response) => {
                resolve(response);
            });
        });
    })

}
/** Handles messages from the YoVilleApp, which are received
 * via inject.js (middleman)
 */
chrome.runtime.onMessage.addListener(
    async (response, sender, sendResponse) => {
        console.log(response)
        try {
            switch (response.cmd) {
                 case 'loadingComplete':
                    await sendWelcomeDialog();
                    break;
				case 'chatMessageReceived':
                    const {messageText, fromServerUserId} = response.data;
                    switch (messageText) {
                        case '/gift':
                            await sendActionTween(fromServerUserId,'GIFT');
							break;
						case '/kiss':
                            await sendActionTween(fromServerUserId,'KISS');
							break;
						case '/mail':
                            await sendActionTween(fromServerUserId,'MESSAGE');
							break;
							/*case yo.SayMessageCommand:
                            await sendChat(msg.substr(4));
                            break; */
						default:
                            await sendActionTween(fromServerUserId,'TOKENS');
                            break;
                    }
            }
        } catch (e) {
            console.log(e)
        }

    }
);

const addOutfitToSwitcher = (outfit) => {

}


const sendActionTween = async (userTo, tweenType) => {
    await sendRequest({
        cmd: 'sendActionTween',
		userTo: userTo,
        type: tweenType
    })
}

const sendWelcomeDialog = async () => {
    await sendRequest({
        cmd: 'sendWelcomeDialog',
        data:{

        }
    })
}
const sendPopup = async (title, message) => {
    await sendRequest({
        cmd: 'sendPopup',
        data: {
            title: title,
            message: message
        }
    })
}

const showCommands = async () => {
    await sendRequest({
        cmd: 'showCommands'
    })
}
export default {
    sendRequest
}